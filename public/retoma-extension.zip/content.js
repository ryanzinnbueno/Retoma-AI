(()=>{
 if(document.querySelector('#retoma-launcher'))return;
 const icon=chrome.runtime.getURL('retoma-icon.png');
 const runtime={contactKey:'',contactName:'',active:false,tracked:false,operator:false,busy:false,sending:false,ready:false,lastFingerprint:'',processedInbound:{},summary:'',needsHuman:false,reason:'',pending:null,lastScan:0,lastStatus:0,lastOutbox:0,error:'',renderKey:'',notifiedKey:'',autoTriedKey:'',dashboardUrl:''};
 const escape=value=>String(value??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
 const normal=value=>String(value||'').replace(/\s+/g,' ').trim().toLocaleLowerCase('pt-BR');
 const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
 const api=payload=>new Promise((resolve,reject)=>chrome.runtime.sendMessage({type:'retoma-api',payload},response=>chrome.runtime.lastError||!response?.ok?reject(new Error(response?.error||chrome.runtime.lastError?.message||'Não foi possível consultar o Retoma.')):resolve(response.data)));
 const operatorStatus=()=>new Promise(resolve=>chrome.runtime.sendMessage({type:'retoma-operator-status'},response=>resolve(!!response?.data?.operator)));
 const genericHeader=/^(dados do perfil|profile details|clique para dados|click for contact|pesquisar|search|menu|online|digitando|typing|visto por último|last seen)$/i;
 function identity(){
  const header=document.querySelector('#main header');if(!header)return null;
  const preferred=[header.querySelector('[data-testid="conversation-info-header-chat-title"]'),header.querySelector('[data-testid="conversation-info-header"] [dir="auto"]'),...header.querySelectorAll('[role="button"] [title], span[title], [dir="auto"]')];
  const values=preferred.flatMap(e=>e?[e.getAttribute('title')?.trim(),e.textContent?.trim()]:[]).filter(v=>v&&v.length<=200&&!genericHeader.test(v)&&!/^\d+ (participantes?|participants?)$/i.test(v));
  const name=values.find(v=>v.length>1);if(!name)return null;
  return {name,key:normal(name).slice(0,200)};
 }
 function bubbleFor(seed){return seed.closest('.message-in, .message-out')||seed.closest('[data-id]')||seed.closest('[data-testid="msg-container"]')||seed;}
 function bubbleRole(node){
  const directional=(node.matches?.('.message-in,.message-out')?node:null)||node.closest?.('.message-in,.message-out')||node.querySelector?.('.message-in,.message-out');
  if(directional?.classList.contains('message-out'))return 'vendedor';if(directional?.classList.contains('message-in'))return 'cliente';
  const id=node.getAttribute?.('data-id')||node.closest?.('[data-id]')?.getAttribute('data-id')||node.querySelector?.('[data-id]')?.getAttribute('data-id')||'';
  if(/^(true|1)_|_(true|1)_/.test(id))return 'vendedor';if(/^(false|0)_|_(false|0)_/.test(id))return 'cliente';
  if(node.querySelector?.('[data-icon="tail-out"],[data-testid*="outgoing" i],[data-testid*="msg-out" i]'))return 'vendedor';
  if(node.querySelector?.('[data-icon="tail-in"],[data-testid*="incoming" i],[data-testid*="msg-in" i]'))return 'cliente';
  const pre=node.querySelector?.('[data-pre-plain-text]')?.getAttribute('data-pre-plain-text')||node.getAttribute?.('data-pre-plain-text')||'';
  if(/\]\s*(Você|You):/i.test(pre))return 'vendedor';if(/^\[[^\]]+\]\s*[^:]+:/i.test(pre))return 'cliente';
  const main=document.querySelector('#main'),rect=node.getBoundingClientRect?.(),mainRect=main?.getBoundingClientRect?.();
  if(rect?.width&&mainRect?.width){const center=rect.left+rect.width/2,mid=mainRect.left+mainRect.width/2,margin=mainRect.width*.06;if(center<mid-margin)return 'cliente';if(center>mid+margin)return 'vendedor';}
  return null;
 }
 function bubbleText(node){
  const selectors='.selectable-text,[data-testid="msg-text"],[data-lexical-text="true"]',elements=[...(node.matches?.(selectors)?[node]:[]),...node.querySelectorAll(selectors)];
  if(!elements.length)elements.push(...node.querySelectorAll('[dir="auto"],[dir="ltr"]'));
  const unique=[...new Set(elements.map(element=>element.textContent?.replace(/\s+/g,' ').trim()).filter(text=>text&&!/^\d{1,2}:\d{2}$/.test(text)))];
  const pieces=unique.filter((text,index)=>!unique.some((other,otherIndex)=>otherIndex!==index&&other.length>text.length&&other.includes(text)));
  if(pieces.length)return pieces.join('\n').trim();const pre=node.matches?.('[data-pre-plain-text]')?node:node.querySelector?.('[data-pre-plain-text]');return pre?.textContent?.replace(/\s+/g,' ').trim()||'';
 }
 function transcript(){
  const main=document.querySelector('#main');if(!main)return [];
  const seeds=[...main.querySelectorAll('.message-in, .message-out, [data-testid="msg-container"], [data-pre-plain-text], [data-id]')],nodes=[...new Set(seeds.map(bubbleFor))],items=[];
  for(const node of nodes){const role=bubbleRole(node);if(!role)continue;const text=bubbleText(node);if(!text||text.length>2000)continue;const previous=items.at(-1);if(previous?.role===role&&previous.text===text)continue;items.push({role,text});}
  return items.slice(-40);
 }
 const fingerprint=items=>items.length?items.at(-1).role+'\0'+normal(items.at(-1).text)+'\0'+items.length:'';
 async function stored(){return (await chrome.storage.local.get(['trackedContacts'])).trackedContacts||{};}
 async function remember(active,subject=''){const contacts=await stored();if(active)contacts[runtime.contactKey]={name:runtime.contactName,subject,active:true};else if(contacts[runtime.contactKey])contacts[runtime.contactKey].active=false;await chrome.storage.local.set({trackedContacts:contacts});return Object.values(contacts).filter(c=>c.active).length;}
 function launcherState(){const launcher=document.querySelector('#retoma-launcher');if(!launcher)return;launcher.classList.toggle('is-active',runtime.active);launcher.classList.toggle('needs-human',runtime.needsHuman);launcher.title=runtime.needsHuman?'Retoma: vendedor solicitado':runtime.active?'Retoma: IA acompanhando':'Abrir Retoma';}
 function notifySeller(){const key=runtime.contactKey+'\0'+runtime.reason;if(!runtime.needsHuman||runtime.notifiedKey===key)return;runtime.notifiedKey=key;chrome.storage.local.get('desktopNotifications').then(settings=>{if(settings.desktopNotifications!==false)chrome.runtime.sendMessage({type:'retoma-notify',title:`${runtime.contactName} precisa de você`,message:runtime.reason||'O cliente solicitou atendimento humano.'});});}
 function applyState(data){const needed=!!data.needsHuman;Object.assign(runtime,{active:!!data.active,tracked:!!data.tracked,summary:data.summary||runtime.summary||'',needsHuman:needed,reason:data.reason||'',pending:data.pending||null,service:data.service||runtime.service||'',error:''});if(needed)notifySeller();}
 function render(){
  launcherState();const panel=document.querySelector('#retoma-panel');if(!panel)return;
  const label=panel.querySelector('#retoma-contact'),status=panel.querySelector('#retoma-status'),body=panel.querySelector('#retoma-dynamic');
  label.textContent=runtime.contactName||'Abra uma conversa';
  status.textContent=!runtime.operator?'Aba de atendimento · automação reservada':runtime.sending&&runtime.pending?.sender==='vendedor'?'Enviando mensagem do Retoma…':runtime.busy?'Processando nova mensagem…':runtime.needsHuman?'Vendedor avisado · IA ainda ativa':runtime.active?'Acompanhamento automático ativo':runtime.tracked?'Atendimento manual':'Ainda não acompanhada';
  status.className='retoma-status '+(runtime.needsHuman?'attention':runtime.active?'online':'');
  const key=JSON.stringify([runtime.contactKey,runtime.active,runtime.tracked,runtime.operator,runtime.busy,runtime.sending,runtime.summary,runtime.needsHuman,runtime.reason,runtime.pending?.requestMessageId,runtime.error,runtime.service]);if(runtime.renderKey===key)return;runtime.renderKey=key;
  const error=runtime.error?`<div class="retoma-error">${escape(runtime.error)}</div>`:'';
  if(!runtime.contactKey){body.innerHTML=error+'<div class="retoma-empty"><b>Abra uma conversa</b><p>A Retoma identifica as novas mensagens do cliente automaticamente.</p></div>';return;}
  if(runtime.active||runtime.pending){body.innerHTML=error+`<section class="retoma-live"><div class="retoma-orbit"><span></span><img src="${icon}" alt=""></div><small>${runtime.operator?'ABA OPERADORA':'ABA DA ATENDENTE'}</small><h2>${runtime.busy?'Entendendo a conversa…':runtime.operator?'Tudo sendo acompanhado.':'Atendimento livre nesta aba.'}</h2><p>${runtime.operator?'A Retoma percorre conversas não lidas, responde e salva o contexto.':'A resposta automática acontece somente na aba marcada como operadora.'}</p></section>${runtime.needsHuman?`<section class="retoma-alert"><b>Você foi avisado</b><p>${escape(runtime.reason||'Esta conversa precisa da avaliação do vendedor.')}</p><small>A IA continua respondendo outras dúvidas até você assumir.</small></section>`:''}${runtime.summary?`<section class="retoma-summary"><span>RESUMO ATUAL</span><p>${escape(runtime.summary)}</p></section>`:''}<div class="retoma-actions"><button id="retoma-pause" class="retoma-secondary">Assumir e pausar a IA</button></div><div class="retoma-tip"><b>Várias conversas</b><p>Novas mensagens são sincronizadas com a central enquanto o WhatsApp Web estiver aberto.</p></div>`;body.querySelector('#retoma-pause')?.addEventListener('click',pause);return;}
  body.innerHTML=error+`<section class="retoma-start"><span class="retoma-step">01</span><h2>Ativar nesta conversa</h2><p>A IA responderá automaticamente usando produtos, regras e respostas ensinadas no Retoma.</p><label>Assunto do orçamento<input id="retoma-subject" maxlength="160" value="${escape(runtime.service||'')}" placeholder="Ex.: fachada em ACM"></label><label class="retoma-check"><input id="retoma-consent" type="checkbox"><span>Confirmo que este contato autorizou o atendimento e o uso desta conversa.</span></label><button id="retoma-activate" class="retoma-primary">Acompanhar com IA</button></section><div class="retoma-tip"><b>Você mantém o controle</b><p>Se o vendedor começar a digitar ou clicar em assumir, a IA pausa imediatamente.</p></div>`;
  body.querySelector('#retoma-activate')?.addEventListener('click',activate);
 }
 function openPanel(){let panel=document.querySelector('#retoma-panel');if(panel){panel.remove();document.querySelector('#retoma-launcher').hidden=false;return;}runtime.renderKey='';panel=document.createElement('aside');panel.id='retoma-panel';panel.innerHTML=`<header><img src="${icon}" alt="Símbolo Retoma"><div><b>retoma</b><small id="retoma-contact">Abra uma conversa</small></div><button type="button" aria-label="Fechar">×</button></header><div class="retoma-panel-body"><div class="retoma-status" id="retoma-status">Conectando…</div><div id="retoma-dynamic"></div><a class="retoma-dashboard" href="${escape(runtime.dashboardUrl||'https://retoma-ai.vercel.app')}" target="_blank">Abrir central de atendimento <span>↗</span></a><footer><span></span>Versão 0.7.0 · mantenha esta aba aberta</footer></div>`;document.body.appendChild(panel);document.querySelector('#retoma-launcher').hidden=true;panel.querySelector('header button').onclick=openPanel;render();}
 async function hydrate(force=false){
  const current=identity();if(!current){runtime.contactKey='';runtime.contactName='';runtime.active=false;runtime.tracked=false;runtime.ready=false;render();return;}
  if(!force&&current.key===runtime.contactKey&&runtime.ready)return;
  if(current.key!==runtime.contactKey){runtime.renderKey='';runtime.error='';runtime.autoTriedKey='';}runtime.contactKey=current.key;runtime.contactName=current.name;runtime.ready=false;runtime.lastFingerprint=fingerprint(transcript());render();
  try{const data=await api({mode:'status',contactKey:current.key,contactName:current.name});applyState(data);Object.assign(runtime,{ready:true,lastStatus:Date.now()});await remember(data.active,data.service||'');render();if(runtime.operator&&data.pending)await deliver(data.pending);else if(runtime.operator&&data.active&&transcript().at(-1)?.role==='cliente')void processCurrent();else if(runtime.operator&&!data.tracked)void maybeAutoActivate();}catch(e){runtime.ready=true;runtime.lastStatus=Date.now();showError(e.message);}
 }
 function showError(message){runtime.busy=false;runtime.error=message;runtime.renderKey='';render();}
 async function maybeAutoActivate(){
  if(!runtime.operator||!runtime.ready||runtime.tracked||runtime.busy||runtime.autoTriedKey===runtime.contactKey)return;const items=transcript(),last=items.at(-1);if(!last||last.role!=='cliente')return;
  const {autoActivateInbound,assistantEnabled}=await chrome.storage.local.get(['autoActivateInbound','assistantEnabled']);if(autoActivateInbound===false||assistantEnabled===false)return;runtime.autoTriedKey=runtime.contactKey;runtime.busy=true;runtime.error='';render();
  try{const data=await api({mode:'activate',contactKey:runtime.contactKey,contactName:runtime.contactName,subject:'Atendimento iniciado pelo cliente',consent:true,messages:items});applyState({...data,active:true,tracked:true});runtime.lastFingerprint=fingerprint(items);await remember(true,'Atendimento iniciado pelo cliente');runtime.busy=false;render();await processCurrent();}catch(e){showError(e.message);}finally{runtime.busy=false;render();}
 }
 async function activate(){if(!runtime.operator){showError('Abra a extensão nesta aba e escolha Usar esta aba para automação.');return;}const panel=document.querySelector('#retoma-panel'),consent=panel?.querySelector('#retoma-consent'),subject=panel?.querySelector('#retoma-subject')?.value.trim();if(!consent?.checked){showError('Confirme a autorização antes de ativar.');return;}const items=transcript();if(!items.length){showError('Ainda não encontrei mensagens de texto. Role a conversa para carregar pelo menos uma mensagem e tente novamente.');return;}runtime.busy=true;runtime.error='';render();try{const data=await api({mode:'activate',contactKey:runtime.contactKey,contactName:runtime.contactName,subject,consent:true,messages:items});applyState({...data,active:true,tracked:true});runtime.busy=false;await remember(true,subject);runtime.lastFingerprint=fingerprint(items);render();if(items.at(-1)?.role==='cliente')await processCurrent();}catch(e){showError(e.message);}}
 async function pause(){if(!runtime.contactKey)return;runtime.busy=true;render();try{await api({mode:'pause',contactKey:runtime.contactKey,contactName:runtime.contactName,messages:transcript()});Object.assign(runtime,{active:false,busy:false,pending:null});await remember(false);render();}catch(e){showError(e.message);}}
 async function sellerTookOver(){if(!runtime.active||runtime.sending||!runtime.contactKey)return;runtime.active=false;runtime.busy=true;render();try{await api({mode:'seller',contactKey:runtime.contactKey,contactName:runtime.contactName,messages:transcript()});await remember(false);}catch(e){showError(e.message);}finally{runtime.busy=false;render();}}
 function composer(){return [...document.querySelectorAll('#main footer [contenteditable="true"]')].find(e=>e.getAttribute('role')==='textbox'||/mensagem|message/i.test(e.getAttribute('aria-label')||''));}
 function sendButton(){const direct=document.querySelector('#main footer button[aria-label="Enviar"],#main footer button[aria-label="Send"],#main footer button[data-testid="compose-btn-send"]');return direct||document.querySelector('#main footer [data-icon="send"]')?.closest('button');}
 async function sendPart(text){const box=composer();if(!box)throw new Error('O campo de mensagem do WhatsApp não foi encontrado. Atualize a página e tente novamente.');if(box.textContent?.trim())throw new Error('Há um texto sendo digitado pelo vendedor. A IA foi pausada para não sobrescrevê-lo.');box.focus();document.execCommand('insertText',false,text);await wait(Math.min(2200,650+text.length*8));const button=sendButton();if(!button)throw new Error('O botão Enviar não foi encontrado. O WhatsApp Web pode ter mudado.');button.click();await wait(950);}
 async function deliver(reply){
  if(!runtime.operator||runtime.sending||runtime.lastDeliveredRequest===reply.requestMessageId)return;runtime.lastDeliveredRequest=reply.requestMessageId;runtime.sending=true;runtime.busy=true;runtime.pending=reply;render();const expected=runtime.contactKey;
  try{const settings=await chrome.storage.local.get(['assistantEnabled','sendAsBlocks','responseDelaySeconds','messagePauseSeconds']);if(reply.sender!=='vendedor'&&settings.assistantEnabled===false){runtime.lastDeliveredRequest='';return;}const parts=settings.sendAsBlocks===false?[reply.text]:(reply.parts?.length?reply.parts:[reply.text]);const delaySeconds=Math.max(0,Math.min(15,Number(settings.responseDelaySeconds??2))),pauseSeconds=Math.max(1,Math.min(6,Number(settings.messagePauseSeconds??2)));if(delaySeconds)await wait(delaySeconds*1000);for(let index=0;index<parts.length;index++){if(!runtime.operator)throw new Error('Esta aba deixou de ser a operadora.');if(identity()?.key!==expected)throw new Error('A conversa mudou antes do envio. Volte ao contato para continuar.');if(index>0)await wait(pauseSeconds*1000);await sendPart(parts[index]);}await api({mode:'sent',contactKey:expected,contactName:runtime.contactName,requestMessageId:reply.requestMessageId,messages:transcript()});runtime.pending=null;runtime.summary=reply.summary||runtime.summary;runtime.needsHuman=reply.needsHuman;runtime.reason=reply.reason||'';runtime.active=reply.sender==='vendedor'?false:!reply.stop;if(runtime.needsHuman)notifySeller();runtime.lastFingerprint=fingerprint(transcript());await remember(runtime.active);}
  catch(e){runtime.lastDeliveredRequest='';if(/sendo digitado/.test(e.message)){runtime.sending=false;await sellerTookOver();}else showError(e.message);}finally{runtime.sending=false;runtime.busy=false;render();}
 }
 async function processCurrent(){
  if(!runtime.operator||runtime.busy||runtime.sending||!runtime.active||!runtime.contactKey)return;const {assistantEnabled}=await chrome.storage.local.get('assistantEnabled');if(assistantEnabled===false)return;const items=transcript(),last=items.at(-1);if(!last||last.role!=='cliente')return;const mark=fingerprint(items);if(runtime.processedInbound[runtime.contactKey]===mark)return;runtime.processedInbound[runtime.contactKey]=mark;runtime.lastFingerprint=mark;runtime.busy=true;render();
  try{const data=await api({mode:'auto',requestId:crypto.randomUUID(),contactKey:runtime.contactKey,contactName:runtime.contactName,consent:true,messages:items});applyState({...data,pending:data.reply||data.pending||null});if(runtime.pending)await deliver(runtime.pending);}
  catch(e){showError(e.message);}finally{runtime.busy=false;render();}
 }
 async function scanUnread(){if(!runtime.operator||runtime.busy||runtime.sending||Date.now()-runtime.lastScan<5000)return;runtime.lastScan=Date.now();const contacts=await stored(),active=Object.values(contacts).filter(c=>c.active),settings=await chrome.storage.local.get('autoActivateInbound');if(!active.length&&settings.autoActivateInbound===false)return;const rows=[...document.querySelectorAll('#pane-side [role="listitem"], #pane-side [role="row"], #pane-side [data-testid="cell-frame-container"]')];for(const row of rows){const title=[...row.querySelectorAll('[title]')].map(e=>e.getAttribute('title')?.trim()).find(value=>value&&!/^\d{1,2}:\d{2}$/.test(value));if(!title||normal(title)===runtime.contactKey)continue;const tracked=active.find(c=>normal(c.name)===normal(title));if(!tracked&&settings.autoActivateInbound===false)continue;const unread=row.querySelector('[aria-label*="não lida" i],[aria-label*="não lidas" i],[aria-label*="unread" i],[data-testid*="unread" i],[data-icon*="unread" i]');if(unread){row.click();await wait(1600);await hydrate(true);break;}}
 }
 async function pollOutbox(){
  if(!runtime.operator||runtime.busy||runtime.sending||Date.now()-runtime.lastOutbox<5000)return false;runtime.lastOutbox=Date.now();
  try{
   const data=await api({mode:'outbox'}),item=data.items?.[0];if(!item)return false;
   if(runtime.contactKey===item.contactKey){await hydrate(true);return true;}
   const rows=[...document.querySelectorAll('#pane-side [role="listitem"], #pane-side [role="row"], #pane-side [data-testid="cell-frame-container"]')];
   const row=rows.find(candidate=>[...candidate.querySelectorAll('[title]')].some(element=>{const title=element.getAttribute('title')?.trim();return title&&(normal(title)===item.contactKey||normal(title)===normal(item.contactName));}));
   if(!row)return false;row.click();await wait(1600);await hydrate(true);return true;
  }catch{return false;}
 }
 const launcher=document.createElement('button');launcher.id='retoma-launcher';launcher.innerHTML=`<img src="${icon}" alt=""><span>Retoma</span><i></i>`;launcher.addEventListener('click',openPanel);document.body.appendChild(launcher);
 document.addEventListener('input',event=>{const target=event.target;if(event.isTrusted&&target instanceof Element&&target.closest('#main footer')&&target.matches('[contenteditable="true"]'))chrome.storage.local.get('pauseOnTyping').then(settings=>{if(settings.pauseOnTyping!==false)void sellerTookOver();});},true);
 const observer=new MutationObserver(changes=>{if(changes.every(change=>change.target instanceof Element&&change.target.closest('#retoma-panel,#retoma-launcher')))return;clearTimeout(runtime.mutationTimer);runtime.mutationTimer=setTimeout(()=>void tick(),500);});observer.observe(document.body,{subtree:true,childList:true});
 async function tick(){if(!runtime.operator){const current=identity();if(current?.key!==runtime.contactKey)await hydrate(true);return;}if(await pollOutbox())return;const current=identity();if(current?.key!==runtime.contactKey)await hydrate(true);else if(current&&runtime.ready&&!runtime.busy&&!runtime.sending&&Date.now()-runtime.lastStatus>10000)await hydrate(true);else if(runtime.active&&!runtime.busy&&!runtime.sending){const items=transcript(),mark=fingerprint(items);if(mark!==runtime.lastFingerprint){const last=items.at(-1);runtime.lastFingerprint=mark;if(last?.role==='cliente')await processCurrent();else if(runtime.ready&&last?.role==='vendedor')await sellerTookOver();}}await scanUnread();}
 runtime.dashboardUrl='https://retoma-ai.vercel.app';
 chrome.runtime.onMessage.addListener(message=>{if(message?.type!=='retoma-operator-changed')return;runtime.operator=!!message.operator;runtime.renderKey='';render();if(runtime.operator)void tick();});
 async function boot(){runtime.operator=await operatorStatus();render();await hydrate(true);}
 setInterval(()=>void tick(),2200);void boot();
})();
